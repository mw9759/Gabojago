-- MySQL Workbench Forward Engineering
-- last update : 05.25-17:53

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema gabojago
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `gabojago` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `gabojago` ;



-- -----------------------------------------------------
-- Table `gabojago`.`members`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `gabojago`.`members` ;

CREATE TABLE IF NOT EXISTS `gabojago`.`members` (
	`user_id` VARCHAR(16) NOT NULL,
	`user_name` VARCHAR(20) NOT NULL,
	`user_password` VARCHAR(100) NOT NULL,
	`salt` VARCHAR(100) NOT NULL,
	`email_id` VARCHAR(20) NULL DEFAULT NULL,
	`email_domain` VARCHAR(45) NULL DEFAULT NULL,
	`join_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`phone_number` VARCHAR(15) NULL DEFAULT NULL,
	PRIMARY KEY (`user_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

-- members테이블 컬럼 추가: refresh_token
alter table `gabojago`.`members`
add column `token` varchar(1000) null default null after `phone_number`;
-- members테이블 컬럼 추가: 슬로건
alter table `gabojago`.`members`
add column `slogun` varchar(1000) null default "Hello world!📷✈️🏕️";
-- members 테이블 컬럼 추가: 프로필사진
alter table `gabojago`.`members`
add column `profile_img` MEDIUMBLOB null default null;
-- members 컬럼 추가 좋아요한 게시글
alter table `gabojago`.`members`
add column `like_boards` longtext null;
-- members 컬럼 추가 좋아요한 관광지
alter table `gabojago`.`members`
add column `like_attractions` longtext null;

-- -----------------------------------------------------
-- Table `gabojago`.`boards`
-- U-유저게시글
-- A-공지사항
-- -----------------------------------------------------
DROP TABLE IF EXISTS `gabojago`.`boards` ;

CREATE TABLE IF NOT EXISTS `gabojago`.`boards` (
	`article_no` INT NOT NULL AUTO_INCREMENT,
	`user_id` VARCHAR(16) NULL DEFAULT NULL,
	`subject` VARCHAR(100) NULL DEFAULT NULL,
	`content` VARCHAR(2000) NULL DEFAULT NULL,
	`hit` INT NULL DEFAULT '0',
	`register_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`type` VARCHAR(5) NOT NULL DEFAULT 'U',
	PRIMARY KEY (`article_no`),
	INDEX `user_id` (`user_id` ASC),
	CONSTRAINT `boards_ibfk_1`
	FOREIGN KEY (`user_id`)
		REFERENCES `gabojago`.`members` (`user_id`)
		ON DELETE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;
-- boards테이블 컬럼 추가: imgs_is_exist===========================================================================================================
alter table `gabojago`.`boards`
add column `imgs_is_exist` varchar(5) null default 'N';
-- boards테이블 컬럼 추가: img_slide_num
alter table `gabojago`.`boards`
add column `img_slide_num`  int null default 0;
-- -- boards 컬럼 추가 댓글 갯수
alter table `gabojago`.`boards`
add column `comments_cnt` integer null default 0;
-- boards 컬럼 추가 좋아요 갯수
alter table `gabojago`.`boards`
add column `like_cnt` integer null default 0;


-- -----------------------------------------------------
-- Table `gabojago`.`board_comments`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `gabojago`.`board_comments` ;

CREATE TABLE IF NOT EXISTS `gabojago`.`board_comments` (
	`comment_no` INT NOT NULL AUTO_INCREMENT,
	`article_no` INT NOT NULL,
	`user_id` VARCHAR(16) NOT NULL,
	`content` VARCHAR(2000) NOT NULL,
	`register_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`type` varchar(5) not null default'U',
	PRIMARY KEY (`comment_no`),
	INDEX `article_no` (`article_no` ASC) ,
	INDEX `user_id` (`user_id` ASC) ,
	CONSTRAINT `board_comments_ibfk_1`
	FOREIGN KEY (`article_no`)
		REFERENCES `gabojago`.`boards` (`article_no`)
		ON DELETE CASCADE,
	CONSTRAINT `adminboard_comments_ibfk_2`
	FOREIGN KEY (`user_id`)
		REFERENCES `gabojago`.`members` (`user_id`)
		ON DELETE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

-- board_comments 수정유무 컬럼 추가
alter table `gabojago`.`board_comments`
add column `is_modify` integer null default 0;


-- -----------------------------------------------------
-- Table `gabojago`.`sido`
-- -----------------------------------------------------
-- CREATE TABLE IF NOT EXISTS `gabojago`.`sido` (
-- 	`sido_code` INT NOT NULL,
-- 	`sido_name` VARCHAR(30) NULL DEFAULT NULL,
-- 	PRIMARY KEY (`sido_code`))
-- ENGINE = InnoDB
-- DEFAULT CHARACTER SET = utf8mb3;



-- -----------------------------------------------------
-- Table `gabojago`.`gugun`
-- -----------------------------------------------------
-- CREATE TABLE IF NOT EXISTS `gabojago`.`gugun` (
-- 	`gugun_code` INT NOT NULL,
-- 	`gugun_name` VARCHAR(30) NULL DEFAULT NULL,
-- 	`sido_code` INT NOT NULL,
-- 	PRIMARY KEY (`gugun_code`, `sido_code`),
-- 	INDEX `gugun_to_sido_sido_code_fk_idx` (`sido_code` ASC),
-- 	CONSTRAINT `gugun_to_sido_sido_code_fk`
--     FOREIGN KEY (`sido_code`)
-- 		REFERENCES `gabojago`.`sido` (`sido_code`))
-- ENGINE = InnoDB
-- DEFAULT CHARACTER SET = utf8mb3;



-- -----------------------------------------------------
-- Table `gabojago`.`attraction_info`
-- -----------------------------------------------------
-- CREATE TABLE IF NOT EXISTS `gabojago`.`attraction_info` (
-- 	`content_id` INT NOT NULL,
-- 	`content_type_id` INT NULL DEFAULT NULL,
-- 	`title` VARCHAR(100) NULL DEFAULT NULL,
-- 	`addr1` VARCHAR(100) NULL DEFAULT NULL,
-- 	`addr2` VARCHAR(50) NULL DEFAULT NULL,
-- 	`zipcode` VARCHAR(50) NULL DEFAULT NULL,
-- 	`tel` VARCHAR(50) NULL DEFAULT NULL,
-- 	`first_image` VARCHAR(200) NULL DEFAULT NULL,
-- 	`first_image2` VARCHAR(200) NULL DEFAULT NULL,
-- 	`readcount` INT NULL DEFAULT NULL,
-- 	`sido_code` INT NULL DEFAULT NULL,
-- 	`gugun_code` INT NULL DEFAULT NULL,
-- 	`latitude` DECIMAL(20,17) NULL DEFAULT NULL,
-- 	`longitude` DECIMAL(20,17) NULL DEFAULT NULL,
-- 	`mlevel` VARCHAR(2) NULL DEFAULT NULL,
-- 	PRIMARY KEY (`content_id`),
-- 	INDEX `attraction_to_content_type_id_fk_idx` (`content_type_id` ASC),
-- 	INDEX `attraction_to_sido_code_fk_idx` (`sido_code` ASC),
-- 	INDEX `attraction_to_gugun_code_fk_idx` (`gugun_code` ASC),
-- 	CONSTRAINT `attraction_to_content_type_id_fk`
-- 	FOREIGN KEY (`content_type_id`)
-- 		REFERENCES `gabojago`.`content_type` (`content_type_id`),
-- 	CONSTRAINT `attraction_to_gugun_code_fk`
-- 	FOREIGN KEY (`gugun_code`)
-- 		REFERENCES `gabojago`.`gugun` (`gugun_code`),
-- 	CONSTRAINT `attraction_to_sido_code_fk`
-- 	FOREIGN KEY (`sido_code`)
-- 		REFERENCES `gabojago`.`sido` (`sido_code`))
-- ENGINE = InnoDB
-- DEFAULT CHARACTER SET = utf8mb3;
-- 추가 --------------------------------------------------
alter table `gabojago`.`attraction_info`
add column `like_cnt` int not null default '0';



-- -----------------------------------------------------
-- Table `gabojago`.`attraction_description`
-- -----------------------------------------------------
-- CREATE TABLE IF NOT EXISTS `gabojago`.`attraction_description` (
-- 	`content_id` INT NOT NULL,
-- 	`homepage` VARCHAR(100) NULL DEFAULT NULL,
-- 	`overview` VARCHAR(10000) NULL DEFAULT NULL,
-- 	`telname` VARCHAR(45) NULL DEFAULT NULL,
-- 	PRIMARY KEY (`content_id`),
-- 	CONSTRAINT `attraction_detail_to_attraciton_id_fk`
--     FOREIGN KEY (`content_id`)
-- 		REFERENCES `gabojago`.`attraction_info` (`content_id`))
-- ENGINE = InnoDB
-- DEFAULT CHARACTER SET = utf8mb3;



-- -----------------------------------------------------
-- Table `gabojago`.`attraction_detail`
-- -----------------------------------------------------
-- CREATE TABLE IF NOT EXISTS `gabojago`.`attraction_detail` (
-- 	`content_id` INT NOT NULL,
-- 	`cat1` VARCHAR(3) NULL DEFAULT NULL,
-- 	`cat2` VARCHAR(5) NULL DEFAULT NULL,
-- 	`cat3` VARCHAR(9) NULL DEFAULT NULL,
-- 	`created_time` VARCHAR(14) NULL DEFAULT NULL,
-- 	`modified_time` VARCHAR(14) NULL DEFAULT NULL,
-- 	`booktour` VARCHAR(5) NULL DEFAULT NULL,
-- 	PRIMARY KEY (`content_id`),
-- 	CONSTRAINT `attraction_detail_to_basic_content_id_fk`
--     FOREIGN KEY (`content_id`)
-- 		REFERENCES `gabojago`.`attraction_info` (`content_id`))
-- ENGINE = InnoDB
-- DEFAULT CHARACTER SET = utf8mb3;



-- -----------------------------------------------------
-- Table `gabojago`.`board_img`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `gabojago`.`board_img` ;

CREATE TABLE IF NOT EXISTS `gabojago`.`board_img` (
	`img_no` int not null auto_increment,
	`article_no` INT NOT NULL,
	`img_blob` MEDIUMBLOB NULL DEFAULT NULL,
	PRIMARY KEY (`img_no`),
	FOREIGN KEY (`article_no`)
		REFERENCES `gabojago`.`boards` (`article_no`)
		ON DELETE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;



-- -----------------------------------------------------
-- Table `gabojago`.`qnA`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `gabojago`.`qnA`;
CREATE TABLE IF NOT EXISTS `gabojago`.`qnA` (
	`article_no` INT NOT NULL AUTO_INCREMENT,
	`user_id` VARCHAR(16) NULL DEFAULT NULL,
	`subject` VARCHAR(100) NULL DEFAULT NULL,
	`content` VARCHAR(2000) NULL DEFAULT NULL,
	`register_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`isanswer` VARCHAR(5) NULL DEFAULT 'N',
	PRIMARY KEY (`article_no`),
    FOREIGN KEY (`user_id`)
		REFERENCES `gabojago`.`members` (`user_id`)
		ON DELETE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;



-- -----------------------------------------------------
-- Table `gabojago`.`qnAResult`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `gabojago`.`qnAResult`;
CREATE TABLE IF NOT EXISTS `gabojago`.`qnAResult` (
	`article_no` INT NOT NULL,
	`user_id` VARCHAR(16) NULL DEFAULT NULL,
	`subject` VARCHAR(100) NULL DEFAULT NULL,
	`content` VARCHAR(2000) NULL DEFAULT NULL,
	`register_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`isanswer` VARCHAR(5) NULL DEFAULT 'N',
	PRIMARY KEY (`article_no`),
	FOREIGN KEY (`user_id`)
		REFERENCES `gabojago`.`members` (`user_id`)
		ON DELETE CASCADE,
    FOREIGN KEY (`article_no`)
		REFERENCES `gabojago`.`qnA` (`article_no`)
		ON DELETE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;



-- -----------------------------------------------------
-- Table `gabojago`.`qnA`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `gabojago`.`qnA`;
CREATE TABLE IF NOT EXISTS `gabojago`.`qnA` (
	`article_no` INT NOT NULL AUTO_INCREMENT,
	`user_id` VARCHAR(16) NULL DEFAULT NULL,
	`subject` VARCHAR(100) NULL DEFAULT NULL,
	`content` VARCHAR(2000) NULL DEFAULT NULL,
	`register_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`isanswer` VARCHAR(5) NULL DEFAULT 'N',
	PRIMARY KEY (`article_no`),
	FOREIGN KEY (`user_id`)
		REFERENCES `gabojago`.`members` (`user_id`)
		ON DELETE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;



-- -----------------------------------------------------
-- Table `gabojago`.`plan`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `gabojago`.`plan`;
CREATE TABLE IF NOT EXISTS `gabojago`.`plan` (
    `user_id` VARCHAR(16) NOT NULL,
    `plan_name` VARCHAR(50) NOT NULL,
    `content` LONGTEXT NOT NULL,
    PRIMARY KEY(`user_id`, `plan_name`),
    FOREIGN KEY (`user_id`)
		REFERENCES `gabojago`.`members` (`user_id`)
		ON DELETE CASCADE
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

-- INDEX
CREATE INDEX idx_plan_name ON `gabojago`.`plan` (`plan_name`);



-- -----------------------------------------------------
-- Table `gabojago`.`attraction_board`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `gabojago`.`attraction_comment`;
CREATE TABLE IF NOT EXISTS `gabojago`.`attraction_comment` (
	`comment_id` INT NOT NULL AUTO_INCREMENT,
	`content_id` INT NOT NULL,
	`user_id` VARCHAR(16) NOT NULL,
	`content` VARCHAR(2000) NULL DEFAULT NULL,
	`register_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `is_modify` INT NOT NULL DEFAULT 0,
	PRIMARY KEY (`comment_id`),
	FOREIGN KEY (`content_id`)
		REFERENCES `gabojago`.`attraction_info` (`content_id`)
		ON DELETE CASCADE
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;