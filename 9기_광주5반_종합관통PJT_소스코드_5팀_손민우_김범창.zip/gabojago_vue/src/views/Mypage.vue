<template>
  <div>
    <router-view></router-view>
  </div>

</template>
<script>
export default {
  name: "my_page",
  data() {
    return {
      
    }
  },
  methods: {
    
  }
};

</script>
<style scoped>
  .top_{
    text-align: center;
    margin: 5%;
    border-bottom: 1px solid;
    font-size: xx-large;
  }
</style>
