package com.gabojago.gabojago;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnjoyTripVueApplicationTests {

	@Test
	void contextLoads() {
	}

}
