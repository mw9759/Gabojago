package com.gabojago.gabojago;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GabojagoApplicationTests {

	@Test
	void contextLoads() {
	}

}
