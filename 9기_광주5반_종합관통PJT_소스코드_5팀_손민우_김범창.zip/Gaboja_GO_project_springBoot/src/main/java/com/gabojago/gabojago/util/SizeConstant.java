package com.gabojago.gabojago.util;

public class SizeConstant {

	public final static int LIST_SIZE = 18;
	public final static int NAVIGATION_SIZE = 10;
	
}
